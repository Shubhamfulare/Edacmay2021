
import  "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "./Pr02.css";
export function Pr02(){

    return(

<div>   
    <br/>
<div className="container bg-light">
    <div className="row">
        <br/><br/><br/><br/>
        <div className="col" style={{paddinTop: 10+'px', fontFamily: "cursive"}}>
            <h1 >Success Stories</h1>
        </div>
        
    </div>
    <div className="row">
        <div className="col-md-2">
            <img src="https://tv-wordpress.s3.amazonaws.com/a/wp-content/uploads/Saroj-R-150x150.png" alt=""/>
        </div>
        <div className="col-10 shadow-lg p-1 mb-5 bg-white rounded">    
             <p><h4>Saroj Raja,UrbanPro's Tutor of the Month</h4>
                We are happy to announce Saroj Raja, a Spoken English Trainer from Gurgaon as our Tutor of the Month. She has been in this profession for the past sixteen years and still continuing. Until now, she has taught 1700 students. The students highly praise her for her knowledge and for providing exciting classes. Saroj Raja studied B.Sc from Loreto House...
             </p>   
        </div>
        <div className="col-md-2">
            <img src="https://tv-wordpress.s3.amazonaws.com/a/wp-content/uploads/Laxmi-Narayana-150x150.png" alt=""/>
        </div>
        <div className="col-10 shadow-lg p-1 mb-5 bg-white rounded">    
             <p><h4>Laxmi Narayana ,UrbanPro's Tutor of the Month</h4>
                We are happy to feature Laxmi Narayana, a Mathematics teacher from Ganeshbasthi, Kothagudem, as our Tutor of the Month. Throughout his journey, he has taught more than 200 students on UrbanPro and is still counting. Many of his students have ranked in their classes and achieved high scores. Laxmi mostly teaches CBSE, ICSE/IGCSE students. His students...
             </p>   
        </div>
        <div className="col-md-2">
            <img src="https://tv-wordpress.s3.amazonaws.com/a/wp-content/uploads/Ravindra-Kumar-Singh-150x150.png" alt=""/>
        </div>
        <div className="col-10 shadow-lg p-1 mb-5 bg-white rounded">    
             <p>
                <h4>Ravindra Kumar Singh, UrbanPro's Tutor of the Month</h4>
                We are happy to feature Ravindra Kumar Singh, an IT professional and Computer Course trainer from Tatanagar, Jamshedpur, as Tutor of the Month. For 24 years, he has been a tutor and teaching several Engineering and IT students. The students are drawn towards him for his commendable way of teaching. As a trainer, he takes immense pleasure in guiding...
             </p>   
        </div>
        <div className="col-md-2">
            <img src="https://tv-wordpress.s3.amazonaws.com/a/wp-content/uploads/Abdul-Gaffar-150x150.png" alt=""/>
        </div>
        <div className="col-10 shadow-lg p-1 mb-5 bg-white rounded">    
             <p><h4>Abdul Gaffar, UrbanPro's Tutor of the Month</h4>
                We are happy to announce Abdul Gaffar, an Arabic Teacher from Antop Hill, Mumbai, as the Tutor of the Month. His journey started thirteen years back. In his career, he worked in Saudi Arabia for seven years. There he worked as an accountant in a resort and taught English to Arabic kids. Then, as he wanted to teach students, he started teaching online...
             </p>   
        </div>
        <div className="col-md-2">
            <img src="https://tv-wordpress.s3.amazonaws.com/a/wp-content/uploads/Sai-Venkatraman-150x150.png" alt=""/>
        </div>
        <div className="col-10 shadow-lg p-1 mb-5 bg-white rounded">    
             <p><h4>Meet Anuj Kumar Pandey, UrbanPro's Tutor of the Month</h4>
                We are happy to feature Anuj Kumar Pandey, an IIT Bombay and Kharagpur pass out from Delhi. He started his journey as a Biology and Biotechnology teacher recently but has become one of the most favourite teachers within this short time. His students find him a tutor who can deliver the lesson promptly. He also has a good command of the topic taught...
             </p>   
        </div>
        <div className="col-md-2">
            <img src="https://tv-wordpress.s3.amazonaws.com/a/wp-content/uploads/Shashi-Ojha-200-%E2%80%93-3-150x150.png" alt=""/>
        </div>
        <div className="col-10 shadow-lg p-1 mb-5 bg-white rounded">    
             <p><h4>	
                Meet Shashi Ojha, UrbanPro's Tutor of the Month</h4>
                We are happy to announce Abdul Gaffar, an Arabic Teacher from Antop Hill, Mumbai, as the Tutor of the Month. His journey started thirteen years back. In his career, he worked in Saudi Arabia for seven years. There he worked as an accountant in a resort and taught English to Arabic kids. Then, as he wanted to teach students, he started teaching online...
             </p>   
        </div>
        <div className="col-md-2">
            <img src="https://tv-wordpress.s3.amazonaws.com/a/wp-content/uploads/soumita-150x150.png" alt=""/>
        </div>
        <div className="col-10 shadow-lg p-1 mb-5 bg-white rounded">    
             <p><h4>Meet Soumita Sen,UrbanPro's Tutor of the Month</h4>
                We are happy to feature Anuj Kumar Pandey, an IIT Bombay and Kharagpur pass out from Delhi. He started his journey as a Biology and Biotechnology teacher recently but has become one of the most favourite teachers within this short time. His students find him a tutor who can deliver the lesson promptly. He also has a good command of the topic taught...
             </p>   
        </div>
    </div>



    <div className="card text-center">
        <div className="card-header">
          Featured
        </div>
        <div className="card-body">
          <h5 className="card-title">Thanks for being here</h5>
          <p className="card-text">Urban-Pro family always welcome you .</p>
          <a href="#" class="btn btn-primary">Go Up</a>
        </div>
        <div className="card-footer text-muted">
          2 days ago
        </div>
      </div>
</div>


</div>
    );
}