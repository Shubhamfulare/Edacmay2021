import { render } from "@testing-library/react";

import bootstrap from "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import img from "./images/Bg.jpeg";


export function Aboutus(){
    
    
    return(


        <div className="wrapper maindiv page-header-image container-fluid">
        <div className=" .img-fluid">
          <br/>
          <br/>
          <h1  className="HeadDiv" style={{textAlign:"center"}}>
            About Us
          </h1>
          <br/>
          <h3  className="HeadDiv2" style={{textAlign:"center"}}>
            Teacher | Students
          </h3>
          <br/>
          <br/>
        </div>
        <div className="story-div">
          <h5 className="story" >
            Our Story
          </h5>
          <p className="story">
            Established in the year 2006, our ISO 9001:2008 certified company, “V.
            P. Pet Polymer”, has been engaged in manufacturing and supplying an
            exemplary array of Pet Preforms, Bottles And Jars. As per the current
            market demands, we are offering Pickle Jars, Pet Jars, HDPE & PP Jars,
            Confectionery Plastic Jars, Toffee Jars and Plastic Candy Jars.
            Offered products are used in various industries for their extreme
            corrosion resistance, spaciousness, toughness, chemical resistance,
            special designs and light weight. In pharmaceutical industry, our
            products are used for keeping antibiotics, cough syrups, vitamins,
            gripe water and suspensions. We making these products available to the
            clients in different sizes, shapes and designs. Therefore, our
            products are highly valuable for domestic purposes for storing
            pickles, salts, sugar and other items used in the kitchen. Owing to
            our team of dedicated professionals, we have been able to bring forth
            excellent product line into the market. We have established
            ultra-modernized infrastructure so that our professionals can
            manufacture the offered product line as per the international quality
            standards. They comprehensively test each product in our advanced
            quality testing laboratory. It is helps us to ensure their quality in
            tandem with the industry laid norms. Due to the quality, our products
            are acclaimed by the clients. To ensure optimum client-satisfaction,
            we manufacture these products as per their specifications. With the
            help of our logistic personal, we deliver these products at the
            clients’ premises within given deadlines.
          </p>
        </div>
      </div>


    );
}