import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "./pr01.css";
import Logo from "./images/Logo.PNG";
import five from "./images/5.jpg";
import six from "./images/6.jpg";
import seven from "./images/7.jpg";
import eight from "./images/8.jpg";
import nine from "./images/9.jpg";
import ten from "./images/10.jpg";
import eleven from "./images/11.jpg";
import twelve from "./images/12.jpg";
import close from "./images/close.png";
import eng from "./images/eng.png";
import his from "./images/his.jpg";
import math from "./images/math.jpg";
import sci from "./images/sci.jpg";

import music from "./images/music.jpg";
import singing from "./images/singing.jpg";
import dance from "./images/dance.jpg";
import cooking from "./images/cooking.jpg";
import { useEffect, useState } from "react";

import axios from "axios";

export function Pr01() {
  return (
    <div>
      <Login></Login>
      <Display></Display>
      <SpecialClasses></SpecialClasses>
      <ActivityClasses></ActivityClasses>
    </div>
  );
}
export function Head() {
  return (
    <div >
      <div className="row container-fluid">
        <div
          className="col-md-4"
          style={{ paddingLeft: 12 + "%", borderRadius: 5 + "px" }}
        >
          <img
            src={Logo}
            style={{
              borderRadius: 15 + "px",
              width: 120 + "px",
              height: 120 + "px",
              float:"left",
          
            }}
          />
        </div>
        <br />
        <div className="col-md-8">
          <h1 className="head">Urban-Pro Find Tutor Or Student</h1>
        </div>
      </div>
    </div>
  );
}

function Login() {
let [userList,setUserlist]=useState([
]
);

const[Fname,setFname]=useState("");
  const[Lname,setLname]=useState("");
  const[email,setEmail]=useState("");
  const[pass,setPass]=useState("");
  const[cpass,setCpass]=useState("");
  const[mobile,setMobile]=useState("");


  const FnameChangeHandler = (e)=> setFname(e.target.value);
  const LnameChangeHandler = (e)=> setLname(e.target.value);
  const EmailChangeHandler = (e)=> setEmail(e.target.value);
  const PassChangeHandler = (e)=> setPass(e.target.value);
  const CpassChangeHandler = (e)=> setCpass(e.target.value);
  const MobileChangeHandler = (e)=> setMobile(e.target.value);


useEffect(()=>{
  readAllUser();
},[]);


const readAllUser=async ()=>{
  let url="http://localhost:3001/read-all";
  const response=await axios.get(url);
  setUserlist(response.data);
}


  const [show, setShow] = useState(false);
  
const addNewUser= async()=>{

const newUser={fname:Fname,lname:Lname,email:email,mobile:mobile};
if(Fname==""||Lname==""){}
else{
  const newlist=[...userList,newUser];
  setUserlist(newlist);

//api calling
let url ="http://localhost:3001/user-create" ;
await axios.post(url,{...newUser});


  setFname("");
  setEmail("");
  setCpass("");
  setPass("");
  setMobile("");
  setLname("");}
}

  function SignUp(props) {
    
    if (!props.show) {
      return null;
    }

    
    return (
      <div className="modal">
        <div className="modal-content">
          <div className="modal_header">
            <button
              className="button-close"
              onClick={() => {
                setShow(false);
              }}
            >
              <img
                src={close}
                style={{
                  width: 30 + "px",
                  height: 30 + "px",
                  marginLeft: -10 + "px",
                  marginRight: -10 + "px",
                  marginTop: -15 + "px",
                  marginBottom: -10 + "px",
                }}
              ></img>
            </button>

            <h4 className="modal-title">Registration</h4>
          </div>

          <form>
            <div className="modal-body">
              <div>
                <label for="fname"> First Name </label>
                <input className="input1" id="fname" type="text" required value={Fname} onChange={FnameChangeHandler} />
                <span id="name" style={{ color: "red" }}></span>
              </div>
              <br />
              <div>
                <label for="lname"> Last Name </label>
                <input className="input1" id="lname" type="text" required value={Lname} onChange={LnameChangeHandler} />
                <span id="namelast" style={{ color: "red" }}></span>
              </div>
              <br />
              <div>
                <label for="email"> Email </label>
                <input className="input1" id="email" type="email" required value={email} onChange={EmailChangeHandler} />
                <span id="emailerror" style={{ color: "red" }}></span>
              </div>
              <br />
              <div>
                <label for="password">Password </label>
                <input
                  className="input1"
                  id="password"
                  type="password"
                  required
                  value={pass}
                  onChange={PassChangeHandler}
                />
                <span id="passerror" style={{ color: "red" }}></span>
              </div>
              <br />
              <div>
                <label for="cpassword"> Confirm Password </label>
                <input
                  className="input1"
                  id="cpassword"
                  type="password"
                  required
                  value={cpass}
                  onChange={CpassChangeHandler}
                />
                <span id="cpasserror" style={{ color: "red" }}></span>
              </div>
              <br />
              <div>
                <label for="mobile"> Mobile No </label>
                <input className="input1" id="mobile" type="tel" required value={mobile} onChange={MobileChangeHandler} />
                <span id="mobileerror" style={{ color: "red" }}></span>
              </div>
              <br />
              <div>
                <label for="dob">Date of birth </label>
                <input className="input1" id="dob" type="date" required />
              </div>
              <br />
              <div>
                <label for="Hobbies">Hobbies </label>
                <input className="input1" id="hobbies" type="text" />
              </div>
              <br />
              <label for="gender">Gender </label>
              <div className="input1">
                <label for="gender">Male </label>&ensp;
                <input type="radio" name="gender " />
                &ensp;
                <label for="gender">Female </label>&ensp;
                <input type="radio" name="gender " />
                &ensp;
                <label for="gender">Other</label>&ensp;
                <input type="radio" name="gender" />
              </div>
              <br />
              <div>
                <br />
                <label for="edu">Education Details </label>
                <select className="ptn input1">
                  <option value="first">Primary Education</option>
                  <option value="second">Higher Education</option>
                  <option value="ug">Under Graduate</option>
                </select>
              </div>
              <br />
              <div>
                <label for="address">Address </label>
                <textarea
                  name="address"
                  id=" "
                  cols="20"
                  rows="1"
                  className="input1"
                  required
                ></textarea>
              </div>
              <br />
              <br />

              <div className="modal-footer">
                <button type="submit" className="btn btn-primary btncss" onClick={addNewUser}>
                  Submit
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="prdiv container-fluid">
      <br></br>
      <section style={{ paddingBottom: 200 + "px" }}>
        <div className="row md={2} " style={{ marginRight: 40 + "px" }}>
          <div className="col-md-8">
            <br />
            <br />

            <p className="runningtext">
              Hello welcome to urban pro your are here with shubham so take
              chill pill...
            </p>
            <p className="runningtext">
              Go live to have an bettter experiance of Urban-Pro
            </p>
          </div>

          <div className="col-md-4 login">
            <p style={{ textAlign: "center", paddingTop: 10 + "px" }}>
              <b style={{ color: "white", fontSize: "large" }}>LOG IN</b>
            </p>
            <select
              class="form-select btn-primary"
              style={{ borderRadius: 4 + "px", padding: 2 + "px" }}
            >
              <option selected>Select option</option>
              <option value="1">Student</option>
              <option value="2">Teacher</option>
            </select>
            <br />
            <br />
            <input class="form-control" type="text" placeholder="Username" />
            <br />
            <input class="form-control" type="text" placeholder="Password" />
            <br />
            <button
              type="button"
              class="btn btn-primary"
              style={{ backgroundColor: "blue" }}
            >
              Log In
            </button>
            <br />
            <br />
            <p style={{ color: "white" }}>
              Don't have an account ?
              <button
                class="btn btn-primary btn-success"
                onClick={() => {
                  setShow(true);
                }}
              >
                Sign Up
              </button>
            </p>
            <br />
          </div>
        </div>
      </section>
      <SignUp show={show}></SignUp>


      <div>
                <table className="table table-dark table-striped m-2">
                  <thead>
                    <tr>
                      <th scope="col">Fname</th>
                      <th scope="col">Lname</th>
                      <th scope="col">Email</th>
                      <th scope="col">Mobile</th>
                    </tr>
                  </thead>
                  <tbody>
                    {
                      userList.map((item)=>{
                        return(
                              <tr>
                                <th>{item.fname}</th>
                                <th>{item.lname}</th>
                                <th>{item.email}</th>
                                <th>{item.mobile}</th>
                              </tr>);}
                      
                      )
                    }
                  </tbody>
                </table>

      </div>



    </div>
  );
}

function Display() {
  return (
    <div>
      <br />
      <br />
      <hr />
      <div class="row container-fluid" style={{ marginLeft: 30 + "px" }}>
        <p className="imgtitle ">Online Regular classes</p>

        <div className="col-md-3 fik ">
          <a href="google.com " style={{ textDecoration: "none" }}>
            <img src={five} alt=" " class="imgall " />
            <br />
            <span class="textimg ">Class 5 Tution</span>
          </a>
        </div>
        <div className="col-md-3 ">
          <a href="google.com " style={{ textDecoration: "none" }}>
            <img src={six} alt=" " class="imgall " />
            <br />
            <span class="textimg ">Class 6 Tution</span>
          </a>
        </div>
        <div class="col-md-3 ">
          <a href=" " style={{ textDecoration: "none" }}>
            <img src={seven} alt=" " class="imgall " />
            <br />
            <span class="textimg ">Class 7 Tution</span>
          </a>
        </div>
        <div class="col-md-3 ">
          <a href=" " style={{ textDecoration: "none" }}>
            <img src={eight} alt=" " class="imgall " />
            <br />
            <span class="textimg ">Class 8 Tution</span>
          </a>
        </div>
        <div class="col-md-3 ">
          <a href=" " style={{ textDecoration: "none" }}>
            <img src={nine} alt=" " class="imgall " />
            <br />
            <span class="textimg ">Class 9 Tution</span>
          </a>
        </div>
        <div class="col-md-3 ">
          <a href=" " style={{ textDecoration: "none" }}>
            <img src={ten} alt=" " class="imgall " />
            <br />
            <span class="textimg ">Class 10 Tution</span>
          </a>
        </div>
        <div class="col-md-3 ">
          <a href=" " style={{ textDecoration: "none" }}>
            <img src={eleven} alt=" " class="imgall " />
            <br />
            <span class="textimg ">Class 11 Tution</span>
          </a>
        </div>
        <div class="col-md-3">
          <a href=" " style={{ textDecoration: "none" }}>
            <img src={twelve} alt=" " class="imgall " />
            <br />
            <span class="textimg">Class 12 Tution</span>
          </a>
        </div>
      </div>
      <hr style={{ color: "rgb(15, 14, 14)" }} />
    </div>
  );
}

function SpecialClasses() {
  return (
    <div>
      <br />
      <div className="row container-fluid" style={{ marginLeft: 30 + "px" }}>
        <p class="imgtitle "> Special classes</p>
        <div class="col-md-3 ">
          <a href=" " style={{ textDecoration: "none" }}>
            <img src={math} alt=" " class="imgall " />
            <br />
            <span class="textimg ">Mathematics Tution</span>
          </a>
        </div>
        <div class="col-md-3 ">
          <a href=" " style={{ textDecoration: "none" }}>
            <img src={sci} alt=" " class="imgall " />
            <br />
            <span class="textimg ">Science Tution</span>
          </a>
        </div>
        <div class="col-md-3 ">
          <a href=" " style={{ textDecoration: "none" }}>
            <img src={his} alt=" " class="imgall " />
            <br />
            <span class="textimg ">History Tution</span>
          </a>
        </div>
        <div class="col-md-3 ">
          <a href=" " style={{ textDecoration: "none" }}>
            <img src={eng} alt=" " class="imgall " />
            <br />
            <span class="textimg ">English Tution</span>
          </a>
        </div>
      </div>
      <hr />
    </div>
  );
}

function ActivityClasses() {
  return (
    <div>
      <div class="row container-fluid" style={{ marginLeft: 30 + "px" }}>
        <p class="imgtitle "> Activity classes</p>
        <div class="col-md-3 ">
          <a href=" " style={{ textDecoration: "none" }}>
            <img src={dance} alt=" " class="imgall " />
            <br />
            <span class="textimg ">Dance</span>
          </a>
        </div>
        <div class="col-md-3 ">
          <a href=" " style={{ textDecoration: "none" }}>
            <img src={cooking} alt=" " class="imgall " />
            <br />
            <span class="textimg ">Cooking</span>
          </a>
        </div>
        <div class="col-md-3 ">
          <a href=" " style={{ textDecoration: "none" }}>
            <img src={music} alt=" " class="imgall " />
            <br />
            <span class="textimg ">Music</span>
          </a>
        </div>
        <div class="col-md-3 ">
          <a href=" " style={{ textDecoration: "none" }}>
            <img src={singing} alt=" " class="imgall " />
            <br />
            <span class="textimg ">Singing</span>
          </a>
        </div>
      </div>
      <hr />
    </div>
  );
}
