import  "../node_modules/bootstrap/dist/css/bootstrap.min.css";

export function Contact(){
    return (



        <div className="container-fluid">
        <br/>
        <br/>
        <div className="row text-md-center">
            <div className="col-md-12 text-md-center p-4">
                <h3 class="bg-success p-2" >Contact Us</h3>
            </div>
            <br/><br/>
            <div className="row">
              <div className="col-md-6">
                  <div className="col p-2">
                    <input className="form-control" type="text" placeholder="Enter your name"/>
                  </div>
                  <div className="col p-2">
                    <input className="form-control" type="text" placeholder="Enter your email"/>
                  </div>  
                  <div className="col p-2">
                    <input className="form-control" type="text" placeholder="Enter your mobile number"/>
                  </div>  
                  <div  className="col p-2">
                    <input class="form-control" type="text" placeholder="Enter your your message"/>
                  </div>  
                  <div className="col p-2">
                    <input className="form-control btn-primary"  type="button" value="Send"/>
                  </div>  
                    
                </div>

            <div class="col-md-6">
                <div class="col p-3">
                    <h5 class="text-primary">Urban-Pro</h5>
                    <h6>F-32,7 hills, Aurangabad-431136, Maharashtra, India</h6>
                </div>
                <div class="col p-3">
                    <h5 class="text-primary">Call</h5>
                    <h6>+91 8888855555</h6>
                </div>
                <div class="col p-3">
                    <h5 class="text-primary">Email</h5>
                    <h6>Education@Urban-Pro.com</h6>
                </div>
            </div>
            <br/><br/>
            <h5>Locate Us</h5>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3752.1540561608235!2d75.34802061422558!3d19.875715731513683!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bdba29ba8b7fed7%3A0xef389d17f8084581!2sSeven%20Hills%20Flyover%20Rd%2C%20Motiwala%20Nagar%2C%20Venkatesh%20Nagar%2C%20M%20G%20M%2C%20Aurangabad%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1627723449628!5m2!1sen!2sin" width="100%" height="250" style={{border:10+'px'}} allowfullscreen="" loading="lazy"></iframe>
             </div>
            </div><br/><br/>
            <div className="elementor-text-editor elementor-clearfix text-center bg-dark text-white"><p>Copyright © 2021 Urban-Pro</p></div>
      
        </div>
    



    );
}