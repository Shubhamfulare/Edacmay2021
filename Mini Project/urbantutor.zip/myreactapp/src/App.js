import logo from "./logo.svg";
import "./App.css";
import  "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import {useState} from "react";
import img from "./images/Bg.jpeg";
import { Aboutus } from "./AboutUs.js";
import {Pr01} from "./pr01"
import{Head} from "./pr01";
import { Pr02 } from "./Pr02";
import {Contact} from "./Contact";
import { BrowserRouter ,Route,Link, Router } from "react-router-dom";
function App() {
                                 
   return (
    <div>
     <Head></Head>
      <Nav></Nav>
      
    </div>
  
  );
}
  
export default App;


 function Nav() {
  return (
    <BrowserRouter>
    <div className="sticky-top">
      <nav class="navbar navbar-expand-lg navbar-light bg-dark ">
        <div class="container-fluid topnav">
          
          <Link to="/" className="active">
            Home
          </Link>
          <a href="#Online classes" className="nav-item">
            Online classes
          </a>
          <a href="#courses" className="nav-item">
            Courses
          </a>
          <a href="#pr.css" className="nav-item">
            Login
          </a>
          <Link to="/aboutus" className="nav-item">
            About Us
          </Link>
          
          <Link to="/successstories" className="nav-item">
            Success Stories
          </Link>

          <Link to="/contact" className="nav-item">
            Contact
          </Link>
          
        </div>
      </nav>







    </div>
    <Route path="/" exact component={Pr01}/>
        <Route path="/aboutus" component={Aboutus}/>
        <Route path="/successstories" component={Pr02}/>
        <Route path="/contact" component={Contact}/>
    </BrowserRouter>
  );
}
