
// const express = require("express");
// const Promise = require("bluebird");
//  const mysql = require("mysql");
//  Promise.promisifyAll(require("mysql/lib/Connection").prototype);
//  Promise.promisifyAll(require("mysql/lib/Pool").prototype);



// const app=express();
// //creating url
// app.get("/",(req,res)=>{
//     res.json();
// })
// // creating url address






// const dbref = {host: "localhost" ,user:"root",password:"cdac"};

//  async function addUser(){
//     const connection = mysql.createConnection(dbref);

//     await connection.connectAsync();

//     let sql=`insert into edac.user (fname,lname,email,mobile)
//                                 values(?,?,?,?)`;
//     const params=["shahbaz","ahsxbs","ansxjs","ahbxhs"];
//     await connection.queryAsync(sql,params);

//     console.log("connection success");
//     connection.endAsync();
// }

// async function readAllUser(){
//     const connection = mysql.createConnection(dbref);

//     await connection.connectAsync();

//     let sql=`select * from edac.user`;
  
//     const list= await connection.queryAsync(sql);

//     console.log(list);
//     connection.endAsync();
// }

// async function readByEmail(){
//     const connection = mysql.createConnection(dbref);

//     await connection.connectAsync();

//     let sql=`select * from edac.user where email=?`;
//     const params=["abc@gmail.com"];
//     const list =await connection.queryAsync(sql,params);

//     console.log(list);
//     connection.endAsync();
// }
// app.listen(3306,()=>{console.log("server started")})

// addUser();