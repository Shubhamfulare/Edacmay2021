// const express = require("express");
// const Promise = require("bluebird");
//  const mysql = require("mysql");
//  Promise.promisifyAll(require("mysql/lib/Connection").prototype);
//  Promise.promisifyAll(require("mysql/lib/Pool").prototype);



// const app=express();


// const dbref = {host: "localhost" ,user:"root",password:"cdac"};

//  async function addUser(){
//     const connection = mysql.createConnection(dbref);

//     await connection.connectAsync();

//     let sql=`insert into edac.user (fname,lname,email,mobile)
//                                 values(?,?,?,?)`;
//     const params=["shahbaz","ahsxbs","ansxjs","ahbxhs"];
//     await connection.queryAsync(sql,params);

//     console.log("connection success");
//     await connection.endAsync();
// }


// addUser();