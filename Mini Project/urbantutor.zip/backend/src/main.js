const cors =require("cors");
const express = require("express");
const Promise = require("bluebird");
 const mysql = require("mysql");
 Promise.promisifyAll(require("mysql/lib/Connection").prototype);
 Promise.promisifyAll(require("mysql/lib/Pool").prototype);



const app=express();
//middleware to read the data sent by user
app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use(cors());

const dbref = {host: "localhost" ,user:"root",password:"cdac"};
//creating url
app.get("/read-all",async (req,res)=>{

    const connection = mysql.createConnection(dbref);

    await connection.connectAsync();

    let sql=`select * from edac.user`;
  
    const list= await connection.queryAsync(sql);

    console.log(list);
    await connection.endAsync();



    res.json(list);
});

app.post("/user-create",async (req,res)=>{
const connection=mysql.createConnection(dbref);
await connection.connectAsync();

const {fname,lname,email,mobile}=req.body;
const sql=`insert into edac.user(fname,lname,email,mobile) values(?,?,?,?)`;
const params=[fname,lname,email,mobile];
await connection.queryAsync(sql,params);
await connection.endAsync();
res.json({message:"user created successfully"});
});




// creating url address
app.listen(3001,()=>{console.log("server started")})





